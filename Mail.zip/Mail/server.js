var express = require('express');
var app = express();
app.use(express.static("public"));

app.get('/index.html', (req, res) => {
  res.sendFile(__dirname + '/public/courriel.html');
});

app.get('/getLetters', (req, res) => {
  res.sendFile(__dirname + '/public/courriel.JSON');
});

app.post('/postLetter', (req, res) => {

});

app.listen(52330);

