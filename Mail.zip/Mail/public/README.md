                ----------------------------- Projet 1, Technologies internet, Lucas G. -----------------------------


- Pourquoi "blueMail" : les couleurs utilisées au début de mon projet étaient le bleu et le beige. Quand j'ai repensé le visuel, j'ai choisi le vert mais je trouvais l'idée intéressante de garder le mot 'blue' alors qu'il n'y a pas de bleu. Ça apporte une originalité.

- Choix des couleurs : j'ai choisis des couleurs et matières actuelles pour donner un aspect moderne et dans l'air du temps, rappellant la nature.

- Choix du style : j'ai voulu un style simple, épuré et intuitif, sans trop d'options inutiles, pour que l'utilisation soit évidente.

- CSS : j'ai fait un CSS pouvant faciliment être modifié pour changer de 'theme' global du site si besoin.

- JS et HTML : j'ai essayé de les faire courts et sans repetitions, afin qu'ils soient faciles à relire et à modifier.

- Choix de l'anglais : j'ai décidé de faire le code en anglais pour 2 raisons : d'abord car c'est la langue habituelle d'un code, et ensuite car je veux pouvoir utilisé ce site dans mon futur portfolio, à destination d'employeurs/clients peut-être pas francophone.

- Commentaires : j'ai essayé de mettre les commentaires de la façon la plus visuele et allégée possible, pour que la relecture soit facile lors de la correction. Le but aussi est de facilement pouvoir lier le serveur lorsque celui-ci sera fait.

- Fonctionnalité : Je me suis basé sur les instructions sur moodle. Je n'ai pas fait de bouton pouvant supprimer les emails pour être le plus proche des instructions qui sont de 'visualiser et rechercher la liste de messages' tandis que pour les carnets d'adresses on parlait également de 'modifier'. 

- Public Key : n'ayant pas encore les connaissances de comment va être utilsée la Public Key, je l'ai inclus dans la creation de chaque contact sans vraiment trop savoir comment ell eva être traîtée par le serveur, mais je sais que je devrais probablement modifier son fonctionnement lorsque j'en saurai d'avantage sur son utilité.

