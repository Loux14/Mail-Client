/*
 *  Permet d'utiliser la librairie NodeRSA dans le navigateur.
 *
 *	Ce fichier doit être compilé avec Browserify (browserify rsa.js -o nodeRSA.js), et ajouter au fichier HTML le .js obtenu.
 */


const NodeRSA = require('node-rsa');

global.window.NodeRSA = NodeRSA;