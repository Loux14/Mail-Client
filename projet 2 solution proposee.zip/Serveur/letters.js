// Un objet Lettre.
class Letter {
	id
	receivedDate;
	content;

	constructor (receivedDate, content) {
		this.id = generateID();
		this.receivedDate = receivedDate;
		this.content = content;
	}

	
}

const fs = require('fs')

/*
 * letters.addLetter(letter : string)
 * 
 * Ajoute aux lettres actuellement stockée une nouvelle.
 * 
 * Double asynchrone.
 * 
 */
exports.addLetter = (letter) => {

	fs.readFile("./data/inbox.json", 'utf8', (err, data) => {
		if (err) throw err;
		let messages = JSON.parse(data);
		
		let letterObject = new Letter(Date.now(), letter)
		messages.push(letterObject);
		console.log("Nouvelle lettre ajoutée.");
		
		fs.writeFile("./data/inbox.json", JSON.stringify(messages, null, '\t'), 'utf8', (err) => {
			if (err) throw err;
		})
	})
}

/*
 * letters.syncLetters(letters : Letter[])
 *
 * Ajoute les lettres que nous n'avions pas déjà dans la boite de réception.
 */
exports.syncLetters = (letters) => {
	fs.readFile("./data/inbox.json", 'utf8', (err, data) => {
		if (err) throw err;
		let messages = JSON.parse(data);
		let nbLetters = 0;
		
		letters.forEach(letter => {
			let alreadyReceived = false;
			messages.forEach(existingLetter => {
				if (existingLetter.id == letter.id) alreadyReceived = true;
			})
			if (!alreadyReceived) {
				letter.receivedDate = Date.now();
				messages.push(letter);
				nbLetters++;
			}

		})
		console.log(nbLetters + " lettres synchronisées, sur un total de " + letters.length);
		
		fs.writeFile("./data/inbox.json", JSON.stringify(messages, null, '\t'), 'utf8', (err) => {
			if (err) throw err;
		})
	})
}

/* 
 * letters.getLetters(callback : function) 
 * 
 * Récupère la liste actuelle des messages enregistrée sur le serveur. Une fois récupérée, getLetters() appelera la 
 * fonction callback(data : Letter[]), avec comme paramètre contenant l'array des messages.
 * 
 * Asynchrone.
 * 
 * 
 */
exports.getLetters = (callback) => {
	
	fs.readFile("./data/inbox.json", 'utf8', (err, data) => {
		if (err) throw err;
		let json = JSON.parse(data);
		let messages = json;
		callback(messages);
	})

}

/*
 * letters.initInbox()
 *
 * Initialise la boite de réception.
 * 
 *  
 */
exports.initInbox = () => {
	
	fs.readFile("./data/inbox.json", 'utf8', (err, data) => {
		if (!data) {
			fs.writeFile("./data/inbox.json", JSON.stringify(new Array(), null, '\t'), 'utf8', (err) => {
				if (err) throw err;
				console.log("Initialisation de l'inbox effectuée.");
			})
		}
	})
}

/*
	* generateID()
	*
	* Retourne un ID unique à utiliser pour un message. C'est un nom de 12 chiffres entre 0 et F.
	* 
	*/
	generateID = () => {
		let s = "";
		for (let i = 0; i < 12; i++) {
			s += Math.floor(Math.random() * 16).toString(16);
		}
		return s.toUpperCase();
	}
