/*
	Script principal pour la messagerie

	Ce script déclare les variables globales de l'application ainsi que son initialisation.
	Ce script doit obligatoirement être introduit dans la page web APRÈS tous les autres du dossier /js.
*/


// Variables globales

// inbox: contient les messages. Devrait toujours être la version "live" de son équivalent dans le localStorage.
var inbox = new Array();

// contactList: la liste de contacts de cet utilisateur. Devrait aussi être la version live des données du localStorage.
var contactList;

// état actuel de l'interface.
var currentPanel = panels.emptyPanel;

// contexte actuel (permet de retourner au bon conteneur)
var currentContext = contexts.none;

// message affiché en ce moment, -1 si non applicable
var currentMessage = -1;

// contact sélectionné en ce moment, -1 si non applicable
var currentContact = -1;

// nom à utiliser pour désigner l'auteur des messages écrits
var nameToUse;

// Initialisation quand le DOM a fini de se charger:
document.addEventListener('DOMContentLoaded', (event) => {
	
	updateStatus("Démarrage de l'application...");


	// Quand le DOM a fini de se loader, on initialise les messages et les contacts, et on popule leurs listes respectives.
	getLetters(() => {
		populateMessages();
		// On initialise puis affiche la vue de lecture des messages.

		readMessagePanelInit()
		showPanel(panels.readMessagesPanel);
	});
	
	initContactList();
	
	populateContactList();

	loadKeys();

	populateKeyFields();

	// On ajoute aux liens en haut de page les fonctions.
	bindHeaderLinks();

	initNameToUse();




})

// Retire l'écran de chargement quand le document a fini de se charger au complet.
document.addEventListener('readystatechange', event => {
	if (document.readyState == "complete") {
		hideLoadingScreen();
	}

	updateStatus("Terminé");
})

// Fermeture de l'écran de chargement
function hideLoadingScreen() {
	document.getElementById("loadingScreen").style="display: none;";
	document.getElementById("frame").style="";
}




