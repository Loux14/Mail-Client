/*
	Fonctions relatives à la composition de messages.
*/

// Ajoute un message à inbox.
function addMessage(titre, senderIndex, contenu) {
	let s = encryptPublicKey(contactList[senderIndex].adress, new Message(titre, nameToUse, Date.now(), contenu) )
	addLetter(s);
}

// Fonction exécutée quand l'utilisateur clique sur Envoyer.
function sendClick() {
	let title = document.getElementById("titleInput").value.escapeSpecialChars();
	let contactValue = document.getElementById("contactAdressInput").value;
	let message = document.getElementById("messageInput").value.escapeSpecialChars();
	
	if (contactValue == "") {
		alert("Veuillez indiquer un destinataire pour ce message.");
		return;
	}

	if (!message) {
		if (!confirm("Ce message n'a aucun contenu. Souhaitez-vous quand même poursuivre?")) {
			return;
		}
	}

	if (!title) {
		if (!confirm("Ce message n'a aucun titre. Souhaitez-vous quand même poursuivre?")) {
			return;
		}
	}

	addMessage(title, Number(contactValue), message);
	clearComposeForm();
	showPanel(panels.readMessagesPanel);
}

// Fonction appelée quand l'utilisateur annule la rédaction d'un message.
function cancelComposeClick() {
	if (confirm("Voulez-vous vraiment abandonner ce message? Toute information sera perdue.")) {
		clearComposeForm();
		showPanel(panels.readMessagesPanel);
	}
}

// Retire toutes les informations du formulaire de rédaction de message.
function clearComposeForm() {
	document.getElementById("titleInput").value = "";
	document.getElementById("contactAdressInput").value = "";
	document.getElementById("messageInput").value = "";
}


// Adding escapeSpecialChars to String, to escape special characters in the message
// Source: https://stackoverflow.com/questions/4253367/how-to-escape-a-json-string-containing-newline-characters-using-javascript/4253415#4253415
String.prototype.escapeSpecialChars = function() {
    return this.replace(/\\n/g, "\\n")
               .replace(/\\'/g, "\\'")
               .replace(/\\"/g, '\\"')
               .replace(/\\&/g, "\\&")
               .replace(/\\r/g, "\\r")
               .replace(/\\t/g, "\\t")
               .replace(/\\b/g, "\\b")
               .replace(/\\f/g, "\\f");
};
