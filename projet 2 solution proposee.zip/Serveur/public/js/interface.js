/*
	Scripts de l'interface de l'application
*/

// La liste des panneaux disponibles dans l'application principale.
const panels = {
	emptyPanel:"programViewEmpty",
	readMessagesPanel: "programViewReadMessages",
	composePanel: "programViewCompose",
	contactsPanel: "programViewContacts",
	encryptionPanel: "programViewEncryption",
	aboutPanel: "programViewAbout"
}

// La liste des contextes d'ajout de contacts disponibles (pour définir le comportement du formulaire d'ajout de contacts.)
const contexts = {
	none: "none",
	fromComposeForm: "fromComposeForm",
	edit: "editContact"
}

// Affiche le panneau d'application principal voulu. Doit être un élément parmi panels.
function showPanel(panel) {
	launchPanelClosedFunction(currentPanel);
	switchActivePanel("programView", panel);
	launchPanelOpenedFunction(panel);
	currentPanel = panel;
	headerLinkSelected(panel);
}

// Fonction à appeler quand un des panneaux de l'application est ouvert
function launchPanelOpenedFunction(panel) {
	switch (panel) {
		case panels.aboutPanel:

			break;

		case panels.composePanel: 

			break;

		case panels.contactsPanel:
			contactPanelOpened();
			break;

		case panels.emptyPanel:
			
			break;

		case panels.readMessagesPanel:
			
			break;

		case panels.encryptionPanel:
			
			break;
	}	
}

// Fonction à appeler quand un des panneaux de l'application est fermé
function launchPanelClosedFunction(panel) {
	switch (panel) {
		case panels.aboutPanel:

			break;

		case panels.composePanel: 

			break;

		case panels.contactsPanel:
			contactPanelClosed();
			break;

		case panels.emptyPanel:
			
			break;

		case panels.readMessagesPanel:
			readMessagePanelClosed();
			break;

		case panels.encryptionPanel:
			
			break;
	}
}

// Ajoute l'attribut "selected" au lien du Header correspondant au panneau actuellement affiché.
function headerLinkSelected(panel) {
	clearAttributeItemList("topHeaderToolBox", "selected");
	switch (panel) {
		case panels.aboutPanel:
			document.getElementById("topHeaderLinkAbout").setAttribute("selected", "true");
			break;

		case panels.composePanel: 
			document.getElementById("topHeaderLinkCompose").setAttribute("selected", "true");
			break;

		case panels.contactsPanel:
			document.getElementById("topHeaderLinkContacts").setAttribute("selected", "true");
			break;

		case panels.emptyPanel:
			break;

		case panels.readMessagesPanel:
			document.getElementById("topHeaderLinkReadMessages").setAttribute("selected", "true");
			break;
		
		case panels.encryptionPanel:
			document.getElementById("topHeaderLinkEncryption").setAttribute("selected", "true");
			break;

	}
}

// Associe la fonction appropriée à chaque bouton du Header.
function bindHeaderLinks() {
	document.getElementById("topHeaderLinkReadMessages").addEventListener("click", (ev) => {
		showPanel(panels.readMessagesPanel);
	})
	document.getElementById("topHeaderLinkCompose").addEventListener("click", (ev) => {
		showPanel(panels.composePanel);
	})
	document.getElementById("topHeaderLinkContacts").addEventListener("click", (ev) => {
		showPanel(panels.contactsPanel);
	})
	document.getElementById("topHeaderLinkAbout").addEventListener("click", (ev) => {
		showPanel(panels.aboutPanel);
	})
	document.getElementById("topHeaderLinkEncryption").addEventListener("click", (ev) => {
		showPanel(panels.encryptionPanel);
	})
}

// Permet de modifier quel élément du conteneur parent qui doit être désormais affiché. (parent et newActivePanel sont les ID.)
function switchActivePanel(parent, newActivePanel) {
	let parentPanel = document.getElementById(parent);
	parentPanel.childNodes.forEach(child => {
		if (child.nodeType == Node.ELEMENT_NODE) {
			if (child.classList.contains("childPanel")) {
				child.style = "display:none";
			}
		}
	})
	document.getElementById(newActivePanel).style = "";
	parentPanel.setAttribute("activePanel", newActivePanel);
}

// Permet d'obtenir quel enfant du conteneur parent est présentement affiché.
function getActivePanel(parent) {
	let parentPanel = document.getElementById(parent);
	if (parentPanel.attributes.getNamedItem("activePanel")) {
		return parentPanel.attributes.getNamedItem("activePanel").value;
	} else {
		return undefined;
	}
}

// Retire l'attribut attribute de tous les enfants du conteneur parent, puis l'ajoute à l'enfant avec l'attribut index spécifié.
function removeAttributeItemList(parent, index, attribute, value = "true") {
	let parentPanel = document.getElementById(parent);
	parentPanel.childNodes.forEach(child => {
		if (child.nodeType == Node.ELEMENT_NODE) {
			if (child.getAttribute(attribute)) {
				child.removeAttribute(attribute);
			}
			if (child.getAttribute("index") == index) {
				child.setAttribute(attribute, value)
			}
		}
	})
}

// Retire l'attribut attribute de tous les enfants du conteneur parent.
function clearAttributeItemList(parent, attribute) {
	let parentPanel = document.getElementById(parent);
	parentPanel.childNodes.forEach(child => {
		if (child.nodeType == Node.ELEMENT_NODE) {
			if (child.getAttribute(attribute)) {
				child.removeAttribute(attribute);
			}
		}
	})
}

// Affiche dans le chat le message.
function updateStatus(text) {
	console.log(text);
}

// Action déclanchée quand le bouton de reset des données est pressé. À faire: utiliser les dialogBoxes plutôt que les messages du navigateur.
function resetButtonClick() {
	if (confirm("Voulez-vous vraiment supprimer toutes les données stockées, telles que les messages et les contacts? Cette action ne peut pas être renversée.")) {
		inbox = new Array();
		contactList = new Array();
		syncContactList();
		syncMessage();
		populateMessages();
		populateContactList();
		updateStatus("Données supprimées.")
	}
}

/* ===== Boîtes de dialogues ===== */
/* Des boîtes de dialogues fait maison. Noirci le Frame et permet de demander une option à l'utilisateur, ou lui faire entrer du texte. */

// Ferme la boite de dialogue actuellement ouverte.
function closeDialogBox() {
	let dialogBox = document.getElementsByClassName("full-frame-dialogbox").item(0);
	if (dialogBox) dialogBox.remove();
}

// Fait une boite de dialogue avec une liste de boutons. buttons est un array d'objets ayant chacun deux propriétés, soit "text" et "action".
// [ { text: "exemple", action: "exemple();" } ]
function createDialogBox(title, body, buttons) {
	return generalCreateDialogInputBox(title, body, false, buttons);
}

// Fait une boite de dialogue avec une liste de boutons et un champ pour entrer des données. Utilisez getDialogBoxInput() dans l'action pour récupérer les données.
function createDialogInputBox(title, body, buttons) {
	return generalCreateDialogInputBox(title, body, true, buttons);
}

// Fonction générale qui permet de créer et générer la boite de dialogue. SVP utiliser les deux fonctions ci-dessus plutôt que celle-ci directement.
function generalCreateDialogInputBox(title,body, input, buttons) {
	let dialogBox = document.createElement("div");
	dialogBox.className = "full-frame-dialogbox";
	dialogBox.onclick = x => closeDialogBox() 
	let htmlButtons = ""
	buttons.forEach(x => {
		htmlButtons += `<div class="dialogbox-button" onclick="${x.action} closeDialogBox();"><span>${x.text}</span></div>`
	})
	let htmlInput = input ? '<input id="dialogbox-input" class="dialogbox-input">' : "" ;
	dialogBox.innerHTML = `<div class="dialogbox-box" onclick="event.stopPropagation();">
	  <div class="dialogbox-title">${title}</div><div class="dialogbox-body">${body}</div>${htmlInput}
	  <div class="dialogbox-interactive">${htmlButtons}</div></div>`;
	document.body.append(dialogBox);
	return dialogBox;
}

// Retourne la valeur de l'input de la boite de dialogue.
function getDialogBoxInput() {
	return document.getElementById("dialogbox-input").value;
}