var key = new window.NodeRSA();

function loadPrivateKey(privateKey) {
	key.importKey(privateKey);
}

function loadPublicKey(publicKey) {
	key.importKey(publicKey);
}

function exportPrivateKey() {
	return key.exportKey('private');
}

function exportPublicKey() {
	return key.exportKey('public');
}

function decrypt(obj) {
	if (key.isPrivate()) {
		let decryptedData = key.decrypt(obj, 'utf8');
		return decryptedData;
	} else {
		return null;
	}
}

function encryptPublicKey(publicKeyData, obj) {
	let publicKey = new window.NodeRSA()
	publicKey.importKey(publicKeyData, 'public');
	return publicKey.encrypt(obj, 'base64');
}

function generateKeys() {
	key.generateKeyPair();
}

// FONCTIONS MANIPULATION CLÉS LOCALSTORAGE

function saveKeys() {
	localStorage.setItem("privateKey", exportPrivateKey());
	localStorage.setItem("publicKey", exportPublicKey());
}

function loadKeys() {
	let privateKey = localStorage.getItem("privateKey");
	if (privateKey) {
		loadPrivateKey(privateKey);
	} else {
		localStorage.setItem("privateKey", "")
	}
	console.log(privateKey);

	let publicKey = localStorage.getItem("publicKey");
	if (publicKey) {
		loadPublicKey(publicKey);
	} else {
		localStorage.setItem("publicKey", "")
	}
	console.log(publicKey);
}


// FONCTIONS INTERFACE

function populateKeyFields() {
	let publicInput = document.getElementById("publicKeyFieldInput");
	if (key.isPublic()) {
		publicInput.value = exportPublicKey();
	} else {
		publicInput.value = "";
	}
	let privateInput = document.getElementById("privateKeyFieldInput");
	if (key.isPrivate()) {
		
		privateInput.value = exportPrivateKey();
	} else {
		privateInput.value = "";
	}
}

function clearKeyFields() {
	let publicInput = document.getElementById("publicKeyFieldInput");
	publicInput.value = "";
	
	let privateInput = document.getElementById("privateKeyFieldInput");
	privateInput.value = "";
}

function generateNewKeyClick() {
	if (!confirm("Voulez-vous vraiment générer une nouvelle clé? Ce processus peut prendre quelques secondes.")) {
		return;
	} else {
		try {
			generateKeys();
			saveKeys();
			populateKeyFields();
		} catch (error) {
			console.log(error);
		}
	}
}

function useNewKeyClick() {
	createDialogInputBox("Utiliser une nouvelle clé privée", "", [ { text: "Annuler", action: "closeDialogBox();" }, { text: "Utiliser", action: "useNewKey(getDialogBoxInput());" }])
}

function useNewKey(newKey) {
	try {
		loadPrivateKey(newKey);
		saveKeys();
		populateKeyFields();
	} catch (error) {
		console.log(error);
	}
}

function initNameToUse() {
	let nameLocalStorage = localStorage.getItem("nameToUse");
	if (nameLocalStorage) {
		nameToUse = nameLocalStorage;
	} else {
		localStorage.setItem("nameToUse", "Utilisateur")
		nameToUse = "Utilisateur"
	}
	document.getElementById("nameToUseInput").value = nameToUse;
}
function nameToUseChanged() {
	let val = document.getElementById("nameToUseInput").value;
	localStorage.setItem("nameToUse", val)
}