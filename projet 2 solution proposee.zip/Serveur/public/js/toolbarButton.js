// Définition du l'élément custom toolbarButton, très simple. Uniquement pour éviter de produire des erreurs lors du parsing.

class toolbarButton extends HTMLDivElement {
	constructor() {
		super();
	}
}