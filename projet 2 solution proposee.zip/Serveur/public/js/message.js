/*
	Fonctions relatives aux messages
*/


// Un objet Message.
class Message {
	title;
	author;
	sentDate;
	content;

	constructor (title, author, sentDate, content) {
		this.title = title;
		this.author = author;
		this.sentDate = sentDate;
		this.content = content;
	}
}

// Création des listes de messages. Si query est spécifié, n'affiche que les messages qui possèdent le texte query dans un de leurs champs.
function populateMessages(query = "") {
	
	// Supression de la liste actuelle.
	const list = document.getElementById("scrollingMessageList");
	while (list.lastElementChild) {
		list.removeChild(list.lastElementChild);
	}

	inbox.forEach((message, i) => {

		let populate = true;

		if (query != "") {
			if (! messageContainsQuery(message, query) ) {
				populate = false;
			}
		}

		if (populate) {
			let item = document.createElement("div");
			item.setAttribute("class", "messageListItem scrollingListItem");
			item.setAttribute("index", i);

			let itemTitle = document.createElement("messageListTitle");
			itemTitle.textContent = message.title;
			item.appendChild(itemTitle);

			let itemAuthor = document.createElement("messageListAuthor");
			itemAuthor.textContent = message.author;
			item.appendChild(itemAuthor);

			let itemSentDate = document.createElement("messageListTimeSent");
			itemSentDate.textContent = new Date(message.sentDate).toLocaleDateString();
			item.appendChild(itemSentDate);

			let itemPreview = document.createElement("messageListPreview");
			let textPreview = message.content.replace(/(?:\r\n|\r|\n)/g, ' ')
			itemPreview.innerHTML = textPreview.substring(0, Math.min(textPreview.length, 180));
			if (textPreview.length > 180) itemPreview.innerHTML += "...";
			item.appendChild(itemPreview);

			item.addEventListener("click", (me, ev) => {
				readMessage(i);
			})

			list.prepend(item);
		}
		
	})
}

// Retourne vrai si un message possède une sous-string query dans un de ses champs.
function messageContainsQuery(message, query) {
	let messageTitle = String(message.title);
	let messageAuthor = String(message.author);
	let messageContent = String(message.content);

	return ( messageTitle.includes(query) || messageAuthor.includes(query) || messageContent.includes(query)) ;
}

// Permet de synchroniser l'inbox dans le localStorage avec l'objet global inbox.
function syncMessage() {
	localStorage.setItem("inbox", JSON.stringify(inbox));
}

// Fonction qui permet d'afficher un message specifique. Utilisé par chaque élément de la liste de gauche des messages.
// i est l'index, dans l'objet inbox, du message à afficher.
function readMessage(i) {
	const readPanel = document.getElementById("readPanel");

	if (document.getElementById("messageReader")) {
		readPanel.removeChild(document.getElementById("messageReader"));
	}

	removeAttributeItemList("scrollingMessageList", i, "selected");
	
	currentMessage = i;
	
	let message = inbox[i]

	let newItem = document.createElement("div");
	newItem.id = "messageReaderView";
	let newTitle = document.createElement("messageReaderTitle");
	newTitle.textContent = message.title;
	newItem.appendChild(newTitle)
	let newAuthor = document.createElement("messageReaderAuthor");
	newAuthor.textContent = message.author;
	newItem.appendChild(newAuthor)
	let newSentDate = document.createElement("messageReaderTimeSent");
	newSentDate.textContent = new Date(message.sentDate).toLocaleDateString();
	newItem.appendChild(newSentDate)
	let newContent = document.createElement("messageReaderContent");
	newContent.innerHTML = message.content.replace(/(?:\r\n|\r|\n)/g, '<br>');
	newItem.appendChild(newContent)
	

	let messageReader = document.createElement("div");
	messageReader.id = "messageReader"
	messageReader.className = "scrollingPanel"
	messageReader.appendChild(newItem)
	
	readPanel.appendChild(messageReader);

	if (document.getElementById("programViewReadMessages").attributes.getNamedItem("activePanel").value != "readPanel") {
		switchActivePanel("programViewReadMessages", "readPanel");
	}
}

// Fonction appelée par le bouton supprimer.
function deleteMessageClick() {
	if (currentMessage != -1) {
		if (!confirm("Voulez-vous vraiment supprimer ce message? Cette action ne peut pas être renversée.")) {
			return;
		} else {
			inbox.splice(currentMessage, 1);
			syncMessage();
			populateMessages();
			switchActivePanel("programViewReadMessages", "emptyReadPanel");
		}
	}
}

// Au départ, le panneau affiché est celui vide.
function readMessagePanelInit() {
	switchActivePanel("programViewReadMessages", "emptyReadPanel");
}

// Fonction appelée quand le panneau de lecture des messages est fermé.
function readMessagePanelClosed() {
	currentMessage = -1;
}

// Fonction appelée quand le bouton rechercher est cliqué.
function searchMessageClick() {
	createDialogInputBox("Rechercher", "", [ { text: "Annuler", action: "closeDialogBox();" }, { text: "Rechercher", action: "searchMessage(getDialogBoxInput());" }])
}

// Fonction appelée quand l'utilisateur clique sur rechercher dans la boite de dialogue Rechercher.
function searchMessage(query) {
	populateMessages(query);
	document.getElementById("searchMessageToolbarButton").style= "display: none;";
	document.getElementById("cancelSearchMessageToolbarButton").style= "";
}

// Fonction appelée quand l'utilisateur annule la recherche.
function cancelSearchMessageClick() {
	populateMessages();
	document.getElementById("searchMessageToolbarButton").style= "";
	document.getElementById("cancelSearchMessageToolbarButton").style= "display: none;";
}