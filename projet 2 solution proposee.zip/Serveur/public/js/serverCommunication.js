/*
 * Gère toutes les communications avec le serveur.
 *
 */


/*
 * getLetters(callback : function)
 * 
 * Récupère les lettres depuis le serveur et les place dans la variable inbox. Lorsque terminé, appelle callback().
 */
async function getLetters(callback) {
	const response = await fetch('/getLetters')
  	var data = await response.json();
	let encryptedMessages = data;
	console.log(encryptedMessages);
	encryptedMessages.forEach((m => {
		try {
			let decrypted = decrypt(m.content);
			if (decrypted) inbox.push(JSON.parse(decrypted));
		} catch (error) {
			console.error(error);
		}
	}))
	console.log(inbox);
	callback();
}
/* 
 * addLetter(letter : String)
 * 
 * Envoie une lettre au serveur. La lettre doit être pré-encryptée.
 */
async function addLetter(letter) {
	const post = await fetch('/addLetter', {
		method: 'POST',
		body: letter
	})
	var response = post.statusText;
	console.log(response);
}