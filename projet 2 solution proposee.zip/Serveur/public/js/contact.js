/*
	Fonctions relatives aux contacts
*/

// L'objet Contact.
class Contact {
	name;
	adress;

	constructor (name, adress) {
		this.name = name;
		this.adress = adress;
	}
}

// Fonction pour ajouter un contact à la liste de contact.
function addContact(name, adress) {
	contactList.push(new Contact(name, adress));
	syncContactList();
	populateContactList();
}

// Fonction pour modifier le contact à l'index spécifié.
function editContact(index, name, adress) {
	contactList[index] = new Contact(name, adress);
	syncContactList();
	populateContactList();
}

// Récupère la liste de contact depuis le localStorage.
function initContactList() {
	let jsonContactList = localStorage.getItem("contactList");
	if (jsonContactList) {
		contactList = JSON.parse(jsonContactList);
	} else {
		localStorage.setItem("contactList", "")
		contactList = new Array();
	}
	
	console.log(contactList);
}

// Rempli les différentes listes de contacts. Si query est spécifié, limite uniquement aux messages qui contient le texte query.
function populateContactList(query = "") {

	// Supression de la liste actuelle.
	const list = document.getElementById("scrollingContactList");
	while (list.lastElementChild) {
		list.removeChild(list.lastElementChild);
	}

	let contactAdressSelector = document.getElementById("contactAdressInput");
	while (contactAdressSelector.lastElementChild) {
		contactAdressSelector.removeChild(contactAdressSelector.lastElementChild);
	}

	contactList.forEach((contact, i) => {
		
		let populate = true;

		if (query != "") {
			if (! (String(contact.name).includes(query)) ) {
				populate = false;
			}
		}

		if (populate) {
			let item = document.createElement("div");
			item.setAttribute("class", "contactListItem scrollingListItem");
			item.setAttribute("index", i);

			let itemName = document.createElement("contactListName");
			itemName.textContent = contact.name;
			item.appendChild(itemName);

			let itemAdress = document.createElement("contactListAdress");
			itemAdress.textContent = contact.adress;
			item.appendChild(itemAdress);

			item.addEventListener("click", (me, ev) => {
				showContact(i);
			})

			list.prepend(item);
		}

		let newOption = document.createElement("option");
		newOption.text = contact.name;
		newOption.setAttribute("value", i);
		contactAdressSelector.append(newOption);
	})

	contactAdressSelector.value = "";

}

// Mets à jour l'objet contactList du localStorage avec l'objet global contactList.
function syncContactList() {
	localStorage.setItem("contactList", JSON.stringify(contactList));
}

// Permet d'afficher un contact depuis la liste de contacts. Appelé par les éléments de gauche de la liste de contacts.
function showContact(i) {
	
	if (document.getElementById("programViewContacts").attributes.getNamedItem("activePanel").value != "contactPanel") {
		switchActivePanel("programViewContacts", "contactPanel");
	}
	
	const contactPanel = document.getElementById("contactPanel");

	if (document.getElementById("contactViewer")) {
		contactPanel.removeChild(document.getElementById("contactViewer"));
	}

	removeAttributeItemList("scrollingContactList", i, "selected");
	
	let contact = contactList[i]

	let item = document.createElement("div");
	item.id = "viewContactView";
	let itemName = document.createElement("viewContactName");
	itemName.textContent = contact.name;
	item.appendChild(itemName);

	let itemAdress = document.createElement("viewContactAdress");
	itemAdress.textContent = contact.adress;
	item.appendChild(itemAdress);
	

	let viewContact = document.createElement("div");
	viewContact.id = "contactViewer"
	viewContact.className = "scrollingPanel"
	viewContact.appendChild(item)
	
	contactPanel.appendChild(viewContact);

	currentContact = i;
}

// Fonction appelée par le bouton pour ajouter un nouveau contact.
function addNewContactClick() {
	currentContext = contexts.none;
	showAddContactForm();
}

// Fonction pour afficher le formulaire de création de contact.
function showAddContactForm() {
	switchActivePanel("programViewContacts", "newContactPanel");
	clearAttributeItemList("scrollingContactList", "selected");
	if (currentContext == contexts.edit) {
		document.getElementById("addContactToolbarButton").textContent = "Modifier le contact";
	} else {
		document.getElementById("addContactToolbarButton").textContent = "Ajouter aux contacts";
	}
}

// Fonction appelée quand l'utilisateur clique sur le bouton Ajouter le contact dans le formulaire pour ajouter un contact.
function addContactClick() {
	let name = document.getElementById("nameInput").value;
	let adress = document.getElementById("adressInput").value;
	
	if (!name) {
		alert("Veuillez indiquer un nom pour ce contact.");
		return;
	}

	if (!adress) {
		alert("Veuillez indiquer une adresse pour ce contact.");
		return;
	}

	
	if (currentContext == contexts.fromComposeForm) {
		addContact(name, adress);
		showPanel(panels.composePanel);
	} else if (currentContext == contexts.edit) {
		editContact(currentContact, name, adress);
		switchActivePanel("programViewContacts", "emptyContactPanel");
	} else {
		addContact(name, adress);
		switchActivePanel("programViewContacts", "emptyContactPanel");
	}

	clearNewContactForm();
}

// Retire toutes les informations entrées dans le formulaire et retire le contexte actuel.
function clearNewContactForm() {
	let nameInput = document.getElementById("nameInput");
	let adressInput = document.getElementById("adressInput");
	
	nameInput.value = "";
	adressInput.value = "";
	currentContext = contexts.none;
}

// Fonction appelée par le bouton ajouter un contact du formulaire de composition d'un nouveau message.
function addNewContactButtonClick() {
	currentContext = contexts.fromComposeForm;
	showPanel(panels.contactsPanel);
	showAddContactForm();
}

// Annule la création d'un nouveau contact
function cancelNewContactClick() {
	clearNewContactForm;
	switchActivePanel("programViewContacts", "emptyContactPanel");
}

// Retire le contact actuellement affiché de la liste des contacts.
function deleteContactClick() {
	if (!confirm("Voulez-vous vraiment supprimer ce contact? Cette action ne peut pas être renversée.")) {
		return;
	} else {
		contactList.splice(currentContact, 1);
		syncContactList();
		populateContactList();
		switchActivePanel("programViewContacts", "emptyContactPanel");
	}
}

// Fonction appelée quand le panneau des contacts est ouvert.
function contactPanelOpened() {
	switchActivePanel("programViewContacts", "emptyContactPanel");
}

// Fonction appelée quand le panneau des contacts est fermé. Permet de mettre à jour l'objet currentContact.
function contactPanelClosed() {
	clearAttributeItemList("scrollingContactList", "selected");
	clearNewContactForm();
	currentContact = -1;
}

// Fonction pour afficher la boite de dialogue rechercher.
function searchContactClick() {
	createDialogInputBox("Rechercher", "", [ { text: "Annuler", action: "closeDialogBox();" }, { text: "Rechercher", action: "searchContact(getDialogBoxInput());" }])
}

// Fonction à exécuter pour rechercher parmi les contacts.
function searchContact(query) {
	populateContactList(query);
	document.getElementById("searchContactToolbarButton").style= "display: none;";
	document.getElementById("cancelSearchContactToolbarButton").style= "";
}

// Annuler la recherche.
function cancelSearchContactClick() {
	populateContactList();
	document.getElementById("searchContactToolbarButton").style= "";
	document.getElementById("cancelSearchContactToolbarButton").style= "display: none;";
}

// Fonction appelée quand le bouton Modifier (un contact) est cliqué.
function editContactClick() {
	currentContext = contexts.edit;
	showAddContactForm();
	document.getElementById("nameInput").value = contactList[currentContact].name;
	document.getElementById("adressInput").value = contactList[currentContact].adress;
}