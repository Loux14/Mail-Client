class Peer {
	name;
	address;
	registredOn;
	lastSyncOn;

	constructor (name, address) {
		this.name = name;
		this.address = address;
		this.registredOn = Date.now();
		this.lastSyncOn = Date.now();
	}
}

const fs = require('fs');
const letters = require("./letters.js")

/*
 * peers(callback : function)
 *
 * Retourne une liste de tous les pairs enregistrés précédemment.
 * Cette fonction appelle la fonction callback(listPeers : string) une fois qu'elle est prête à retourner la liste de pairs.
 * La liste retournée sera sous forme de JSON.
 * 
 */
exports.peers = (callback) => {
	fs.readFile("./data/peers.json", 'utf8', (err, data) => {
		if (err) throw err;
		callback(data);
	})
}

/*
 * peers.synchronise(name : string, address : string, callback : function)
 * 
 * Retourne une liste des messages pour un pair. Cette fonction demande le nom et l'addresse du pair, qui sera
 * sauvegardée si elle n'est pas encore dans la liste des pairs que l'on connait. Si le pair est déjà connu, il
 * peut demander à ce qu'on lui envoie que les nouveaux messages depuis la dernière fois qu'il s'est synchronisé.
 * 
 * Cette fonction appelle la fonction callback(data : Letter[]) quand elle est prête à partager la liste des
 * messages.
 * 
 */
exports.synchronise = (name, address, callback) => {

	fs.readFile("./data/peers.json", 'utf8', (err, data) => {
		if (err) throw err;
		let list = JSON.parse(data);
		let lastSyncOn = -1;

		list.forEach(peerObserved => {
			if (peerObserved.name == name && peerObserved.address == address) {
				lastSyncOn = peerObserved.lastSyncOn;
				peerObserved.lastSyncOn = Date.now();
				console.log("Le pair était déjà connu.")
			}
		});

		// Si le pair est inconnu, on l'ajoute à la liste.
		if (lastSyncOn == -1) {
			list.push(new Peer(name, address));	
			console.log("Le pair a été ajouté.")
		}

		letters.getLetters(data => {
			callback(data);
		});
		
		fs.writeFile("./data/peers.json", JSON.stringify(list, null, '\t'), 'utf8', (err) => {
			if (err) throw err;
			console.log("Liste des pairs mise à jour.");
		})
	});
}

/*
 * peers.registerPeer (name : string, address : string)
 *
 * Enregistre un nouveau pair manuellement dans la liste de pairs. Utile pour déclarer pour la première fois un nouveau serveur.
 * 
 */
exports.registerPeer = (name, address) => {
	fs.readFile("./data/peers.json", 'utf8', (err, data) => {
		if (err) throw err;
		let list = JSON.parse(data);
		let alreadyKnown = false;

		list.forEach(peerObserved => {
			if (peerObserved.name == name && peerObserved.address == address) {
				alreadyKnown = true;
			}
		});

		// Si le pair est inconnu, on l'ajoute à la liste.
		if (!alreadyKnown) {
			list.push(new Peer(name, address));	
			console.log("Le pair a été ajouté.")
		} else {
			console.log("Le pair était déjà connu.")
		}

		fs.writeFile("./data/peers.json", JSON.stringify(list, null, '\t'), 'utf8', (err) => {
			if (err) throw err;
		})
	});
}

exports.initPeers = () => {
	
	fs.readFile("./data/peers.json", 'utf8', (err, data) => {
		if (!data) {
			fs.writeFile("./data/peers.json", JSON.stringify(new Array(), null, '\t'), 'utf8', (err) => {
				if (err) throw err;
				console.log("Initialisation de la liste de pairs effectuée.");
			})
		}
	})
}