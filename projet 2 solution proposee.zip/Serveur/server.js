
// PARAMÈTRES DU SERVEUR:

// Entrez ici le port du serveur à utiliser. On peut aussi le spécifier comme argument dans la ligne de commande.
var port = process.argv[2] ? Number(process.argv[2]) : 8888;

// Entrez ici le nom que le serveur doit avoir auprès de ses pairs. On peut aussi le spécifier comme second argument dans la ligne de commande.
var serverName = process.argv[3] ? process.argv[3] : "Courriel1";

// Entrez ici l'addresse locale du serveur. Par défaut, localhost + port.
var localAdress = "localhost:" + port;


var express = require("express"),
	app = express(),
	path = require('path'),
	http = require('http');

// Les fonctions relatives aux lettres sont ici.
var letters = require("./letters.js")

// Les fonctions des pairs sont ici.
var peers = require("./peers.js")

// Les fichiers dans /public sont disponibles en tout temps.
app.use(express.static("public"));

app.use(express.json()) // for parsing application/json
app.use(express.text()) // for parsing text

letters.initInbox();
peers.initPeers();

// Quand on se connecte à la racine, on obtient le client email.
app.get("/", (req, res, next) =>  {
	var options = {
	  	root: path.join(__dirname, 'public')
	}
  
	var fileName = "/courriel.htm"
	res.sendFile(fileName, options, function (err) {
	  	if (err) {
			next(err)
	  	} else {
			console.log('Sent:', fileName)
	  	}
	})
})

// GET getLetters : renvoie la liste des messages.
app.get("/getLetters", (req, res) => {
	letters.getLetters((data) => {
		res.type('json');
		res.status(200).send(data);
		console.log("getLetters envoyés");
	})
})

// GET sync/:name/:address : renvoie une liste de messages à un pair, et enregistre ce pair si ce n'est pas déjà fait.
// Si déjà enregistré, n'envoie que les nouveaux messages.
app.get("/sync/:name/:address", (req, res) => {
	peers.synchronise(req.params.name, req.params.address, list => {
		res.type('json');
		res.status(200).send(JSON.stringify(list));
		console.log("Synchronisé avec " + req.params.name);
	});
})

// GET peers : renvoie une liste des pairs.
app.get("/peers", (req, res) => {
	peers.peers(list => {
		res.type('json');
		res.status(200).send(list);
		console.log("peers envoyés!");
	})
})

app.get("/registerPeer/:name/:address", (req, res) => {
	console.log("Nouvelle demande d'enregistrement de pair.")
	res.send();
	peers.registerPeer(req.params.name, req.params.address);
})

// POST addLetter : rajoute une lettre à la liste.
app.post("/addLetter", (req, res) => {
	let letter = req.body;
	letters.addLetter(letter);
	res.status(200).send(letter);
})

// GET syncServer : Demande au serveur de se synchroniser avec ses pairs.
app.get("/syncServer", (req, res) => {
	res.send();
	console.log("Synchronisation initiée!");
	peers.peers(data => {
		let peersList = JSON.parse(data);
		peersList.forEach(peer => {
			try {
				console.log("Connexion à http://" + peer.address + "/sync/" + serverName + "/" + localAdress);
				http.get("http://" + peer.address + "/sync/" + serverName + "/" + localAdress, (res) => {
					/*
					code : https://nodejs.org/api/http.html#httpgeturl-options-callback
					*/

					const { statusCode } = res;
					const contentType = res.headers['content-type'];
				
					let error;
					// Any 2xx status code signals a successful response but
					// here we're only checking for 200.
					if (statusCode !== 200) {
						error = new Error('Request Failed.\n' +
										`Status Code: ${statusCode}`);
					} else if (!/^application\/json/.test(contentType)) {
						error = new Error('Invalid content-type.\n' +
										`Expected application/json but received ${contentType}`);
					}
					if (error) {
						console.error(error.message);
						// Consume response data to free up memory
						res.resume();
						return;
					}
				
					res.setEncoding('utf8');
					let rawData = '';
					res.on('data', (chunk) => { rawData += chunk; });
					res.on('end', () => {
						try {
							let parsedData = JSON.parse(rawData);
							letters.syncLetters(parsedData);
						} catch (e) {
							console.error(e.message);
						}
					});
				})
			} catch (error) {
				console.error(error)
			}
		})
	})
})




// GET * : Si qqun essaye d'accéder à qqchose d'autre, on retourne une page 404.
app.get("*", (req, res) => {
	res.status(404).send("... J'ai aucune idée de ce que tu cherches.");
  });

app.listen(port, function(err){
    if (err) console.log(err);
    console.log("Serveur lancé.");
});


